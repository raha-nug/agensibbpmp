function goToHome() {
    window.location.href = 'admin.html'; // Redirect to the appropriate home page
}

// Additional JS functions can be added here to handle search functionality or other interactions
